Put the required original CSV datasets in this folder. Do not commit private or restricted data.
Expected files are listed in the root README.md.
